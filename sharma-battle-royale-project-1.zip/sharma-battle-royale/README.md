# Sharma Battle Royale

मुफ्त शुरुआती 2D battle-royale Android game. इसमें टच कंट्रोल, 8 दुश्मन, फायर बटन, हेल्थ और सिकुड़ता सेफ ज़ोन है। यह अभी 3D या ऑनलाइन मल्टीप्लेयर गेम नहीं है।

## APK बनाना
इस प्रोजेक्ट की फाइलें `sharma-battle-royale` GitHub repository में डालें। फिर GitHub के Actions टैब में `Build Android APK` रन होगा। सफल रन में `sharma-battle-royale-debug-apk` artifact से `app-debug.apk` डाउनलोड करें।
